package HexTech.Backend_lV_Fatec_Embraer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendLVFatecEmbraerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendLVFatecEmbraerApplication.class, args);
	}

}
