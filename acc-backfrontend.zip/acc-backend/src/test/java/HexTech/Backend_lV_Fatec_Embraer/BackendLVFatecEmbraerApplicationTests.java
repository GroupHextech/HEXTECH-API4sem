package HexTech.Backend_lV_Fatec_Embraer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendLVFatecEmbraerApplicationTests {

	@Test
	void contextLoads() {
	}

}
