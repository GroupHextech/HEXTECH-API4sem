package br.edu.hextech.dailyplane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyplaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
